#!/usr/bin/env bash
set -euo pipefail

# repo-relative sources
SRC_CFG_DIR="./.config/syncuser"
SRC_LIB_DIR="./.local/share/syncuser"

# destinations in the current user's $HOME
DST_CFG_DIR="${HOME}/.config/syncuser"
DST_LIB_DIR="${HOME}/.local/share/syncuser"
DST_BIN_DIR="${HOME}/.local/bin"

mkdir -p "${DST_CFG_DIR}" "${DST_LIB_DIR}" "${DST_BIN_DIR}"

# copy config lists (do NOT overwrite existing)
for f in appconfig.list bin.list certs.list dotfiles.list; do
   if [[ -f "${DST_CFG_DIR}/${f}" ]]; then
      echo "[info] ${DST_CFG_DIR}/${f} exists; leaving as-is."
   else
      cp -f "${SRC_CFG_DIR}/${f}" "${DST_CFG_DIR}/${f}"
      echo "[ok]   installed ${DST_CFG_DIR}/${f}"
   fi
done

# copy runtime scripts (always overwrite—safe to upgrade)
cp -f "${SRC_LIB_DIR}/"*.sh "${DST_LIB_DIR}/"
chmod 0755 "${DST_LIB_DIR}/"*.sh
echo "[ok]   installed runtime to ${DST_LIB_DIR}/"

# install the main command directly as ~/.local/bin/syncuser
# (no wrapper file in the repo needed)
cp -f "${SRC_LIB_DIR}/main_syncuser.sh" "${DST_BIN_DIR}/syncuser"
chmod 0755 "${DST_BIN_DIR}/syncuser"
echo "[ok]   installed ${DST_BIN_DIR}/syncuser"

echo
echo "Add to PATH if needed: export PATH=\"${DST_BIN_DIR}:\$PATH\""
