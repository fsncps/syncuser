#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

LIST="${1:-}"
[[ -n "$LIST" ]] || die "missing certs list"

# Rules:
# - copy only if missing; do NOT delete
# - if --OVERWRITE -> overwrite
# - after copy, chmod 600 on files (not dirs)

if [[ "${SYNCUSER_OVERWRITE}" -eq 1 ]]; then
   RSYNC_OPTS="-azH"
   MODE="overwrite"
else
   RSYNC_OPTS="-azH --ignore-existing"
   MODE="once"
fi

COPIED_TARGETS=()

each_line "$LIST" | while IFS= read -r SRC; do
   [[ -e "$SRC" ]] || {
      warn "missing source: $SRC"
      continue
   }
   DEST="$(map_target_path "$SRC")" || {
      warn "outside HOME (skip): $SRC"
      continue
   }

   _mkdir_target "$(dirname "$DEST")"
   _rsync_remote "$SRC" "$DEST" "$RSYNC_OPTS"
   COPIED_TARGETS+=("$DEST")
   info "cert ${MODE}: $DEST"
done

# tighten perms (files only)
if [[ "${#COPIED_TARGETS[@]}" -gt 0 ]]; then
   # build a safe command that chmods files that exist
   CMD=""
   for p in "${COPIED_TARGETS[@]}"; do
      # quote each path; chmod 600 only if it's a file
      CMD+="if [ -f '$p' ]; then chmod 600 '$p'; fi;"
   done
   [[ -n "$CMD" ]] && _on_target "$CMD"
fi
