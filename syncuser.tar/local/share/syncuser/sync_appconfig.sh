#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

LIST="${1:-}"
[[ -n "$LIST" ]] || die "missing appconfig list"

# Rules:
# - overwrite existing
# - delete files missing on source
# - chown dest_user:users (remote or local)

RSYNC_OPTS="-azH --delete"

each_line "$LIST" | while IFS= read -r SRC; do
   [[ -e "$SRC" ]] || {
      warn "missing source: $SRC"
      continue
   }
   DEST="$(map_target_path "$SRC")" || {
      warn "outside HOME (skip): $SRC"
      continue
   }

   _mkdir_target "$(dirname "$DEST")"
   _rsync_remote "$SRC" "$DEST" "$RSYNC_OPTS"

   # Ownership enforcement (usually already correct for remote copies).
   _on_target "chown -R '${SYNCUSER_TARGET_USER}:users' '$(dirname "$DEST")' 2>/dev/null || true"

   info "appconfig synced: $DEST"
done
