#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

LIST="${1:-}"
[[ -n "$LIST" ]] || die "missing dotfiles list"

# Rules:
# - copy only if missing
# - do NOT delete
# - if --OVERWRITE is set, then overwrite

if [[ "${SYNCUSER_OVERWRITE}" -eq 1 ]]; then
   RSYNC_OPTS="-azH"
   MODE="overwrite"
else
   RSYNC_OPTS="-azH --ignore-existing"
   MODE="once"
fi

each_line "$LIST" | while IFS= read -r SRC; do
   [[ -e "$SRC" ]] || {
      warn "missing source: $SRC"
      continue
   }
   DEST="$(map_target_path "$SRC")" || {
      warn "outside HOME (skip): $SRC"
      continue
   }

   _mkdir_target "$(dirname "$DEST")"
   _rsync_remote "$SRC" "$DEST" "$RSYNC_OPTS"

   info "dotfile ${MODE}: $DEST"
done
