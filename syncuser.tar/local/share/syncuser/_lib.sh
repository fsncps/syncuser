#!/usr/bin/env bash
set -euo pipefail

die() {
   echo "[err] $*" >&2
   exit 1
}
info() { echo "[info] $*"; }
warn() { echo "[warn] $*" >&2; }

# Compute target path: replace local $HOME prefix with target's $HOME.
# If source is not under our $HOME, we warn and skip (user-only policy).
map_target_path() {
   local src="$1"
   local h="$HOME"
   case "$src" in
   "${h}"/*) echo "${SYNCUSER_TARGET_HOME}${src#$h}" ;;
   *)
      echo ""
      return 1
      ;;
   esac
}

# rsync wrappers
_rsync_remote() {
   local src="$1" dest="$2" opts="$3"
   if [[ -z "${SYNCUSER_TARGET_HOST}" ]]; then
      # local copy
      rsync $opts "$src" "$dest"
   else
      rsync -e "ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new" $opts "$src" "${SYNCUSER_TARGET_USER}@${SYNCUSER_TARGET_HOST}:$dest"
   fi
}

# ensure dir on target
_mkdir_target() {
   local dir="$1"
   if [[ -z "${SYNCUSER_TARGET_HOST}" ]]; then
      mkdir -p "$dir"
   else
      ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new "${SYNCUSER_TARGET_USER}@${SYNCUSER_TARGET_HOST}" "mkdir -p '$dir'"
   fi
}

# run on target
_on_target() {
   local cmd="$1"
   if [[ -z "${SYNCUSER_TARGET_HOST}" ]]; then
      bash -lc "$cmd"
   else
      ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new "${SYNCUSER_TARGET_USER}@${SYNCUSER_TARGET_HOST}" "$cmd"
   fi
}

# iterate non-comment, non-empty lines
each_line() {
   local list="$1"
   grep -vE '^[[:space:]]*(#|$)' "$list" || true
}
