#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_lib.sh"

LIST="${1:-}"
[[ -n "$LIST" ]] || die "missing bin list"

# Rules:
# - always copy & overwrite into ~/.local/bin
# - do NOT delete extra files in target's bin dir
# - chmod +x after copy

BIN_DIR="${SYNCUSER_TARGET_HOME}/.local/bin"
_mkdir_target "$BIN_DIR"

each_line "$LIST" | while IFS= read -r SRC; do
   [[ -f "$SRC" ]] || {
      warn "not a file: $SRC"
      continue
   }
   BASENAME="$(basename "$SRC")"
   DEST="${BIN_DIR}/${BASENAME}"

   _rsync_remote "$SRC" "$DEST" "-azH"
   _on_target "chmod 0755 '$DEST'"

   info "bin installed: $DEST"
done
